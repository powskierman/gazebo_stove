The Weather � 2006 monolistic arts.
All rights reserved.

By downloading these icons/images you agree to the following conditions:

My icons are free for personal use, but they are my property and are copyrighted.
They must not be used commercially without agreeing terms with me first.
You can distribute them for free as long as the icon/image sets are unmodified and this text file is included with the 
zip/rar file. 
You may not repackage them & redistribute them with other icon sets, themes, downloads etc. without my permission.
They must not be converted to any other format & distributed without my permission.
You may not sell them or use them for profit either individually, or in any sort of collection or CD package.
If you want to use my icons/images on a web page, in software, in a theme etc. you must obtain permission from me first.
If I agree, credit to me and a link to my site must be placed on your site/in your software/Readme file etc, whichever applies. These works are for personal use only, if you wish to use them in a commercial manner contact me with your request (email below).

I am not liable for any sort of damage done to your computer from using my icons. 
You got them for free, so if you choose to use them then you take full responsibility for anything that may happen by 
using them after you download them. They are provided on an "As-Is" basis and I am not liable to provide any support for the icons, however you may contact me via the below email or through my deviantArt account (note only please) in the event that you require help.


Do not take credit for creating my icons or images. If you have any questions regarding any of my icons/images please email me at:
rik.kyle@gmail.com

Enjoy your new icons!  

monolistic arts
http://monolistic.deviantart.com